#ifndef _PGM_H_
#define _PGM_H_

/*
 * This header contains sample code for reading and writing PGM headers.
 *
 * Note: the reader/writer functions may not be fully general
 *       for the PGM spec, but will work with files following
 *       the format in 'example.pgm'
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PGM_DEBUG 0
#define MAX_LINE_LENGTH 200
#define MAX_COLS 16

static inline char _toupper(char ch) {
  if (ch >= 'a' && ch <= 'z')
    return ch - 'a' + 'A';
  return ch;
}

static int _readPGMHeader(FILE *openfp, int *rows, int *cols, int *maxgrey) {

  char line[MAX_LINE_LENGTH];

  // read magic number
  fgets(line,sizeof(line),openfp);
  if (ferror(openfp) || !(_toupper(line[0]) == 'P' && line[1] == '2')) {
    return -1;
  }

  // read optional comment (up to 199 characters + null terminator)
  fgets(line, sizeof(line), openfp);

  // read rows cols
  char *tok = NULL;
  fgets(line, sizeof(line), openfp);
  tok = strtok(line, " \t\n");
  sscanf(tok,"%d",cols);
  tok = strtok(NULL, " \t\n");
  sscanf(tok,"%d",rows);
  tok = NULL;

  // read maxgrey
  fgets(line, sizeof(line), openfp);
  sscanf(line,"%d",maxgrey);

  if (ferror(openfp) || *rows <= 0 || *cols <= 0 || *maxgrey <= 0) {
    return -1;
  }
  return 0;
}

static int _readPGMData(FILE *openfp, int **data, int dsize) {

  char line[MAX_LINE_LENGTH];
  char *tok = NULL;
  // read data
  *data = (int*)malloc(sizeof(int)*dsize);
  if (*data == NULL) {
    return -1;
  }

  int i = 0;
  while (fgets(line, sizeof(line), openfp)) {
    if (ferror(openfp)) {
      return -1;
    }
    tok = strtok(line, " \t\n");
    while (tok != NULL) {
      sscanf(tok,"%d",&((*data)[i++]));
      tok = strtok(NULL, " \t\n");
    }
  }

  if (ferror(openfp) || i != dsize) {
    return -1;
  }
  return i;
}

int readPGM(FILE *openfp, int **data, int *rows, int *cols, int *maxgrey) {
  if (openfp == NULL) {
    *data = NULL;
    return -1;
  }

  if (_readPGMHeader(openfp, rows, cols, maxgrey) != 0) {
    *data = NULL;
    return -1;
  }

  if (_readPGMData(openfp, data, (*rows)*(*cols)) != (*rows)*(*cols)) {
    *data = NULL;
    return -1;
  }

  return 0;
}

static int _writePGMHeader(FILE *outfp, const char *s, int rows, int cols, int maxgrey) {
  // write header
  fprintf(outfp,"P2\n");
  if (s) {
     fprintf(outfp,"# %s\n",s);
  }
  fprintf(outfp,"%d %d\n",cols,rows);
  fprintf(outfp,"%d\n",maxgrey);
  
  return ferror(outfp);
}

static int _writePGMData(FILE *outfp, int *data, int dsize) {
  // write data
  int i = 0;
  while (i < dsize) {
    if ((i % MAX_COLS) == (MAX_COLS - 1)) {
      fprintf(outfp, "%3d\n", data[i++]);      
    } else {
      fprintf(outfp, "%3d ", data[i++]);
    }
  }
  if (ferror(outfp)) return -1;
  return i;
}

// returns 0 if no error writing to file
int writePGM(FILE *outfp, const char *s, int *data, int rows, int cols, int maxgrey) {

  if (rows <= 0 || cols <= 0 || maxgrey <= 0) {
    return -1;
  }

  if (_writePGMHeader(outfp, s, rows, cols, maxgrey)) {
    return -1;
  }

  if (_writePGMData(outfp, data, rows*cols) != rows*cols) {
    return -1;
  }

  return 0;
}

#endif // _PGM_H_
