#include <stdio.h>
#include <stdlib.h>
#include "pgm.h"

int main(int argc, char **argv) {

  if (argc != 2) {
    printf("usage: ./test-pgm <pgm-file>\n");
    return EXIT_FAILURE;
  }

  FILE *fpin;
  fpin = fopen(argv[1],"r");  
  int * data;
  int rows = -1, cols = -1, maxgrey = -1;
  int rdres = readPGM(fpin, &data, &rows, &cols, &maxgrey);
  if (rdres != 0) {
    printf("PGM read error\n");
    return EXIT_FAILURE;
  }
  fclose(fpin);

  if (data == NULL) {
    printf("PGM read error\n");
    return EXIT_FAILURE;
  }

  printf("rows: %d cols: %d\n",rows,cols);
  printf("maxgrey: %d\n",maxgrey);

  FILE *fpout;
  fpout = fopen("out.pgm","w");
  const char *s = "out.pgm";
  int res = writePGM(fpout, s, data, rows, cols, maxgrey);
  fclose(fpout);
  if (res != 0) {
    printf("PGM Write error");
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
